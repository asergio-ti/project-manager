// Exportação temporária até termos os schemas
export const dadiSchemas = {}; 