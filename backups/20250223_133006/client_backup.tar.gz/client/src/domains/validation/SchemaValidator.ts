// Validação de schemas
