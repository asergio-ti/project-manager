// Estado da timeline
