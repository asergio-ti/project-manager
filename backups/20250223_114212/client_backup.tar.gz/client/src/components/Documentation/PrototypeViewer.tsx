// Visualizador de protótipos
