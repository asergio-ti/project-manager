// Distribuição de informações
