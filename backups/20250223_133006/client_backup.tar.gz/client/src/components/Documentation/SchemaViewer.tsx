// Visualizador humanizado
