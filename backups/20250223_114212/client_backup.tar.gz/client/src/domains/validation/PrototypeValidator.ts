// Validação de protótipos
