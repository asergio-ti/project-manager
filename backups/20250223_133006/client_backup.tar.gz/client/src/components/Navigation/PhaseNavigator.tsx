// Navegação entre fases
